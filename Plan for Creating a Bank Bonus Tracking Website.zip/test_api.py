import requests
import json

def test_api_endpoints():
    """Test the API endpoints to see if they're working"""
    
    api_url = "https://2g8h3ilclk0x.manus.space/api"
    
    # Test creating a bank
    print("Testing bank creation...")
    bank_data = {
        "name": "Test Bank",
        "logo": "",
        "website": "https://testbank.com"
    }
    
    try:
        response = requests.post(f"{api_url}/banks", json=bank_data, timeout=10)
        print(f"Bank creation response: {response.status_code}")
        print(f"Response text: {response.text}")
        
        if response.status_code in [200, 201]:
            bank_info = response.json()
            bank_id = bank_info.get('id')
            print(f"Bank created with ID: {bank_id}")
            
            # Test creating a bonus
            print("\nTesting bonus creation...")
            bonus_data = {
                "title": "Test Bonus $100",
                "bank_id": bank_id,
                "bonus_amount": 100,
                "min_deposit": 1000,
                "direct_deposit_required": True,
                "direct_deposit_amount": 500,
                "holding_period": 90,
                "additional_requirements": "Test requirements",
                "expiration_date": None,
                "link": "https://testbank.com/bonus",
                "is_active": True
            }
            
            bonus_response = requests.post(f"{api_url}/bonuses", json=bonus_data, timeout=10)
            print(f"Bonus creation response: {bonus_response.status_code}")
            print(f"Response text: {bonus_response.text}")
        
    except Exception as e:
        print(f"Error: {str(e)}")
    
    # Test getting bonuses
    print("\nTesting bonus retrieval...")
    try:
        get_response = requests.get(f"{api_url}/bonuses", timeout=10)
        print(f"Get bonuses response: {get_response.status_code}")
        bonuses = get_response.json()
        print(f"Number of bonuses: {len(bonuses)}")
        if bonuses:
            print(f"First bonus: {bonuses[0]}")
    except Exception as e:
        print(f"Error getting bonuses: {str(e)}")

if __name__ == "__main__":
    test_api_endpoints()

