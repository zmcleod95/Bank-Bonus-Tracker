from flask import Blueprint, jsonify
from src.models.models import TrackedBonus, Bonus, Bank, db
from sqlalchemy import func
from datetime import datetime, timedelta

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/dashboard', methods=['GET'])
def get_dashboard_data():
    # Get player statistics
    player_stats = []
    
    for player_id in [1, 2]:
        # Get completed bonuses
        completed_bonuses = TrackedBonus.query.filter_by(
            player_id=player_id, 
            status='completed',
            is_active=True
        ).all()
        
        # Calculate total earned
        total_earned = sum(tb.actual_earnings for tb in completed_bonuses)
        
        # Get pending bonuses
        pending_bonuses = TrackedBonus.query.filter(
            TrackedBonus.player_id == player_id,
            TrackedBonus.status != 'completed',
            TrackedBonus.status != 'failed',
            TrackedBonus.is_active == True
        ).all()
        
        # Calculate pending amount
        pending_amount = 0
        for tb in pending_bonuses:
            bonus = Bonus.query.get(tb.bonus_id)
            if bonus:
                pending_amount += bonus.bonus_amount
        
        player_stats.append({
            'playerId': player_id,
            'totalEarned': total_earned,
            'completedBonuses': len(completed_bonuses),
            'pendingBonusAmount': pending_amount,
            'pendingBonuses': len(pending_bonuses)
        })
    
    # Calculate household total
    household = {
        'totalEarned': sum(player['totalEarned'] for player in player_stats),
        'completedBonuses': sum(player['completedBonuses'] for player in player_stats),
        'pendingBonusAmount': sum(player['pendingBonusAmount'] for player in player_stats),
        'pendingBonuses': sum(player['pendingBonuses'] for player in player_stats)
    }
    
    # Get upcoming dates
    upcoming_dates = []
    
    # Get all active tracked bonuses that are not completed or failed
    active_tracked_bonuses = TrackedBonus.query.filter(
        TrackedBonus.status != 'completed',
        TrackedBonus.status != 'failed',
        TrackedBonus.is_active == True
    ).all()
    
    for tb in active_tracked_bonuses:
        bonus = Bonus.query.get(tb.bonus_id)
        bank = Bank.query.get(bonus.bank_id) if bonus else None
        
        date_entry = {
            'trackedBonusId': tb.id,
            'playerId': tb.player_id,
            'bonusTitle': bonus.title if bonus else '',
            'bankName': bank.name if bank else '',
            'status': tb.status,
            'directDepositRequired': bonus.direct_deposit_required if bonus else False,
            'directDepositComplete': tb.direct_deposit_complete
        }
        
        # Calculate earliest withdrawal date
        if tb.account_open_date and bonus:
            account_open_date = tb.account_open_date
            earliest_withdrawal_date = account_open_date + timedelta(days=bonus.holding_period)
            date_entry['earliestWithdrawalDate'] = earliest_withdrawal_date.isoformat()
        
        upcoming_dates.append(date_entry)
    
    # Sort by earliest withdrawal date
    upcoming_dates.sort(
        key=lambda x: datetime.fromisoformat(x['earliestWithdrawalDate']) if 'earliestWithdrawalDate' in x else datetime.max
    )
    
    return jsonify({
        'players': player_stats,
        'household': household,
        'upcomingDates': upcoming_dates
    })

