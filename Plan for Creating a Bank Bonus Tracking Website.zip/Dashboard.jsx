import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { DollarSign, PiggyBank, Clock, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import StatCard from '@/components/dashboard/StatCard';
import DateCard from '@/components/dashboard/DateCard';
import TrackedBonusCard from '@/components/tracking/TrackedBonusCard';
import { usePlayer } from '@/context/PlayerContext';
import api from '@/lib/api';
import { formatCurrency } from '@/lib/utils';

const Dashboard = () => {
  const { currentPlayer, currentPlayerName } = usePlayer();
  const [dashboardData, setDashboardData] = useState(null);
  const [activeTrackedBonuses, setActiveTrackedBonuses] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch dashboard data
  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        const data = await api.getDashboardData();
        setDashboardData(data);
        
        // Fetch tracked bonuses for current player
        const trackedBonuses = await api.getPlayerTrackedBonuses(currentPlayer);
        
        // Filter active tracked bonuses
        const active = trackedBonuses
          .filter(tb => tb.is_active && tb.status !== 'completed' && tb.status !== 'failed')
          .slice(0, 3); // Limit to 3 for the dashboard
        
        setActiveTrackedBonuses(active);
        setIsLoading(false);
      } catch (err) {
        setError(err.message);
        setIsLoading(false);
      }
    };

    fetchData();
  }, [currentPlayer]);

  // Handle updating a tracked bonus
  const handleUpdateTrackedBonus = async (trackedBonus) => {
    // This would open a dialog in a real implementation
    console.log('Update tracked bonus:', trackedBonus);
  };

  // Handle editing a tracked bonus
  const handleEditTrackedBonus = async (trackedBonus) => {
    // This would open a dialog in a real implementation
    console.log('Edit tracked bonus:', trackedBonus);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading dashboard data...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <p className="text-red-500 mb-4">Error loading dashboard data</p>
          <Button onClick={() => window.location.reload()}>Retry</Button>
        </div>
      </div>
    );
  }

  if (!dashboardData) {
    return null;
  }

  // Get player stats
  const playerStats = dashboardData.players.find(p => p.playerId === currentPlayer) || {
    totalEarned: 0,
    completedBonuses: 0,
    pendingBonusAmount: 0,
    pendingBonuses: 0
  };

  // Format upcoming dates for DateCard
  const upcomingDates = dashboardData.upcomingDates
    .filter(date => date.playerId === currentPlayer)
    .map(date => {
      let title = '';
      let description = '';
      
      if (date.status === 'account_opened' && date.directDepositRequired && !date.directDepositComplete) {
        title = 'Direct Deposit Due';
        description = `For ${date.bankName} ${date.bonusTitle.split(' ').pop()}`;
      } else if (date.status === 'requirements_met') {
        title = 'Bonus Expected';
        description = `From ${date.bankName}`;
      } else if (date.earliestWithdrawalDate) {
        title = 'Holding Period Ends';
        description = `For ${date.bankName}`;
      }
      
      return {
        date: date.earliestWithdrawalDate,
        title,
        description
      };
    })
    .filter(date => date.title); // Remove empty titles

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">{currentPlayerName}'s Dashboard</h1>
        <Button asChild>
          <Link to="/tracking" className="flex items-center">
            <Plus className="mr-2 h-4 w-4" />
            Track New Bonus
          </Link>
        </Button>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard 
          title="Total Earnings" 
          value={formatCurrency(playerStats.totalEarned)}
          icon={DollarSign}
          valueClassName="text-green-600"
        />
        <StatCard 
          title="Completed Bonuses" 
          value={playerStats.completedBonuses}
          icon={PiggyBank}
        />
        <StatCard 
          title="Pending Amount" 
          value={formatCurrency(playerStats.pendingBonusAmount)}
          icon={Clock}
        />
        <StatCard 
          title="Active Bonuses" 
          value={playerStats.pendingBonuses}
          icon={PiggyBank}
        />
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <div className="md:col-span-2 space-y-4">
          <h2 className="text-xl font-semibold tracking-tight">Active Tracked Bonuses</h2>
          
          {activeTrackedBonuses.length === 0 ? (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-6">
                  <h3 className="text-lg font-medium mb-2">No active bonuses</h3>
                  <p className="text-muted-foreground mb-4">Start tracking bank bonuses to see them here.</p>
                  <Button asChild>
                    <Link to="/bonuses">Browse Bonuses</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 md:grid-cols-2">
              {activeTrackedBonuses.map(trackedBonus => (
                <TrackedBonusCard 
                  key={trackedBonus.id}
                  trackedBonus={trackedBonus}
                  bonus={trackedBonus.bonus}
                  bank={trackedBonus.bank}
                  onUpdate={handleUpdateTrackedBonus}
                  onEdit={handleEditTrackedBonus}
                />
              ))}
              
              {activeTrackedBonuses.length < playerStats.pendingBonuses && (
                <Card className="flex items-center justify-center">
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <p className="text-muted-foreground mb-4">
                        {playerStats.pendingBonuses - activeTrackedBonuses.length} more active {playerStats.pendingBonuses - activeTrackedBonuses.length === 1 ? 'bonus' : 'bonuses'}
                      </p>
                      <Button asChild variant="outline">
                        <Link to="/tracking">View All</Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          )}
        </div>

        <div className="space-y-4">
          <h2 className="text-xl font-semibold tracking-tight">Important Dates</h2>
          <DateCard dates={upcomingDates} />
          
          <h2 className="text-xl font-semibold tracking-tight mt-6">Household Total</h2>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-medium">Combined Earnings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Total Earned:</span>
                  <span className="font-medium text-green-600">
                    {formatCurrency(dashboardData.household.totalEarned)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Completed Bonuses:</span>
                  <span className="font-medium">
                    {dashboardData.household.completedBonuses}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Pending Amount:</span>
                  <span className="font-medium">
                    {formatCurrency(dashboardData.household.pendingBonusAmount)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Active Bonuses:</span>
                  <span className="font-medium">
                    {dashboardData.household.pendingBonuses}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

