import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask
from src.models.models import db, Bank, Bonus, TrackedBonus, PlayerSettings
from datetime import datetime, timedelta

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{os.getenv('DB_USERNAME', 'root')}:{os.getenv('DB_PASSWORD', 'password')}@{os.getenv('DB_HOST', 'localhost')}:{os.getenv('DB_PORT', '3306')}/{os.getenv('DB_NAME', 'mydb')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

def seed_database():
    with app.app_context():
        # Create tables if they don't exist
        db.create_all()
        
        # Check if data already exists
        if Bank.query.count() > 0:
            print("Database already has data. Skipping seed.")
            return
        
        # Create banks
        banks = [
            Bank(
                name="Chase",
                logo="https://example.com/chase-logo.png",
                website="https://chase.com",
                description="Chase Bank offers various checking and savings accounts."
            ),
            Bank(
                name="Bank of America",
                logo="https://example.com/bofa-logo.png",
                website="https://bankofamerica.com",
                description="Bank of America offers a variety of financial products."
            ),
            Bank(
                name="Wells Fargo",
                logo="https://example.com/wellsfargo-logo.png",
                website="https://wellsfargo.com",
                description="Wells Fargo provides banking services nationwide."
            ),
            Bank(
                name="Citibank",
                logo="https://example.com/citi-logo.png",
                website="https://citibank.com",
                description="Citibank offers a range of banking services and products."
            ),
            Bank(
                name="Capital One",
                logo="https://example.com/capitalone-logo.png",
                website="https://capitalone.com",
                description="Capital One offers credit cards, checking and savings accounts, auto loans, and more."
            )
        ]
        
        db.session.add_all(banks)
        db.session.commit()
        
        # Create bonuses
        today = datetime.now().date()
        expiration_date = today + timedelta(days=180)
        
        bonuses = [
            Bonus(
                bank_id=1,
                title="Chase Total Checking $300 Bonus",
                bonus_amount=300.00,
                interest_rate=0.01,
                min_deposit=0.00,
                holding_period=90,
                direct_deposit_required=True,
                direct_deposit_amount=500.00,
                direct_deposit_frequency="monthly",
                additional_requirements="Must keep account open for 90 days.",
                expiration_date=expiration_date,
                link="https://chase.com/bonus",
                is_active=True
            ),
            Bonus(
                bank_id=2,
                title="Bank of America $200 Bonus",
                bonus_amount=200.00,
                interest_rate=0.02,
                min_deposit=100.00,
                holding_period=60,
                direct_deposit_required=False,
                direct_deposit_amount=0.00,
                direct_deposit_frequency="",
                additional_requirements="Must make 10 debit card purchases.",
                expiration_date=expiration_date,
                link="https://bankofamerica.com/bonus",
                is_active=True
            ),
            Bonus(
                bank_id=3,
                title="Wells Fargo $400 Bonus",
                bonus_amount=400.00,
                interest_rate=0.01,
                min_deposit=25.00,
                holding_period=120,
                direct_deposit_required=True,
                direct_deposit_amount=1000.00,
                direct_deposit_frequency="one-time",
                additional_requirements="Must keep account open for 120 days.",
                expiration_date=expiration_date,
                link="https://wellsfargo.com/bonus",
                is_active=True
            ),
            Bonus(
                bank_id=4,
                title="Citibank $700 Bonus",
                bonus_amount=700.00,
                interest_rate=0.03,
                min_deposit=15000.00,
                holding_period=90,
                direct_deposit_required=True,
                direct_deposit_amount=5000.00,
                direct_deposit_frequency="monthly",
                additional_requirements="Must maintain $15,000 minimum balance for 90 days.",
                expiration_date=expiration_date,
                link="https://citibank.com/bonus",
                is_active=True
            ),
            Bonus(
                bank_id=5,
                title="Capital One $250 Bonus",
                bonus_amount=250.00,
                interest_rate=0.10,
                min_deposit=0.00,
                holding_period=60,
                direct_deposit_required=True,
                direct_deposit_amount=250.00,
                direct_deposit_frequency="monthly",
                additional_requirements="Must make 3 debit card purchases.",
                expiration_date=expiration_date,
                link="https://capitalone.com/bonus",
                is_active=True
            )
        ]
        
        db.session.add_all(bonuses)
        db.session.commit()
        
        # Create tracked bonuses
        application_date = today - timedelta(days=30)
        account_open_date = today - timedelta(days=25)
        
        tracked_bonuses = [
            TrackedBonus(
                player_id=1,
                bonus_id=1,
                status="account_opened",
                application_date=application_date,
                account_open_date=account_open_date,
                initial_deposit=1000.00,
                direct_deposit_complete=False,
                direct_deposit_date=None,
                bonus_received_date=None,
                completion_date=None,
                actual_earnings=0.00,
                notes="Applied online. Account opened without issues.",
                is_active=True
            ),
            TrackedBonus(
                player_id=2,
                bonus_id=2,
                status="requirements_met",
                application_date=application_date - timedelta(days=20),
                account_open_date=account_open_date - timedelta(days=20),
                initial_deposit=500.00,
                direct_deposit_complete=True,
                direct_deposit_date=today - timedelta(days=10),
                bonus_received_date=None,
                completion_date=None,
                actual_earnings=0.00,
                notes="Completed all requirements. Waiting for bonus.",
                is_active=True
            ),
            TrackedBonus(
                player_id=1,
                bonus_id=3,
                status="planned",
                application_date=None,
                account_open_date=None,
                initial_deposit=0.00,
                direct_deposit_complete=False,
                direct_deposit_date=None,
                bonus_received_date=None,
                completion_date=None,
                actual_earnings=0.00,
                notes="Planning to apply next week.",
                is_active=True
            ),
            TrackedBonus(
                player_id=2,
                bonus_id=4,
                status="completed",
                application_date=application_date - timedelta(days=120),
                account_open_date=account_open_date - timedelta(days=120),
                initial_deposit=15000.00,
                direct_deposit_complete=True,
                direct_deposit_date=today - timedelta(days=100),
                bonus_received_date=today - timedelta(days=30),
                completion_date=today - timedelta(days=10),
                actual_earnings=700.00,
                notes="Successfully completed. Received full bonus amount.",
                is_active=True
            )
        ]
        
        db.session.add_all(tracked_bonuses)
        db.session.commit()
        
        # Create player settings
        player_settings = [
            PlayerSettings(
                player_id=1,
                name="Player 1"
            ),
            PlayerSettings(
                player_id=2,
                name="Player 2"
            )
        ]
        
        db.session.add_all(player_settings)
        db.session.commit()
        
        print("Database seeded successfully!")

if __name__ == "__main__":
    seed_database()

