import csv
import requests
import json
import time

def upload_bonuses_via_api(csv_file_path, api_base_url):
    """Upload bank bonuses from CSV file to the deployed API"""
    
    banks_created = 0
    bonuses_created = 0
    errors = []
    
    # Read the CSV file
    with open(csv_file_path, 'r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        rows = list(reader)
        total_rows = len(rows)
        
        print(f"Processing {total_rows} bank bonuses...")
        
        for i, row in enumerate(rows, 1):
            try:
                print(f"\nProcessing {i}/{total_rows}: {row['title']}")
                
                # First, create or get the bank
                bank_data = {
                    "name": row['bank_name'],
                    "logo": "",
                    "website": row['link'] if row['link'] else ""
                }
                
                # Try to create the bank
                try:
                    bank_response = requests.post(f"{api_base_url}/banks", json=bank_data, timeout=30)
                    
                    if bank_response.status_code == 201:
                        bank_info = bank_response.json()
                        bank_id = bank_info.get('id')
                        banks_created += 1
                        print(f"  ✓ Created bank: {bank_data['name']}")
                    elif bank_response.status_code == 200:
                        bank_info = bank_response.json()
                        bank_id = bank_info.get('id')
                        print(f"  ✓ Bank already exists: {bank_data['name']}")
                    else:
                        # Try to get existing bank by name
                        banks_response = requests.get(f"{api_base_url}/banks", timeout=30)
                        if banks_response.status_code == 200:
                            banks = banks_response.json()
                            existing_bank = next((b for b in banks if b['name'] == bank_data['name']), None)
                            if existing_bank:
                                bank_id = existing_bank['id']
                                print(f"  ✓ Found existing bank: {bank_data['name']}")
                            else:
                                print(f"  ✗ Error creating bank {bank_data['name']}: {bank_response.text}")
                                errors.append(f"Bank creation failed for {bank_data['name']}")
                                continue
                        else:
                            print(f"  ✗ Error creating bank {bank_data['name']}: {bank_response.text}")
                            errors.append(f"Bank creation failed for {bank_data['name']}")
                            continue
                            
                except requests.exceptions.RequestException as e:
                    print(f"  ✗ Network error creating bank: {str(e)}")
                    errors.append(f"Network error for bank {bank_data['name']}")
                    continue
                
                # Parse numeric values safely
                bonus_amount = 0
                try:
                    bonus_amount = float(row['bonus_amount']) if row['bonus_amount'] else 0
                except (ValueError, TypeError):
                    bonus_amount = 0
                
                min_deposit = 0
                try:
                    min_deposit = float(row['min_deposit']) if row['min_deposit'] else 0
                except (ValueError, TypeError):
                    min_deposit = 0
                
                direct_deposit_amount = 0
                try:
                    direct_deposit_amount = float(row['direct_deposit_amount']) if row['direct_deposit_amount'] else 0
                except (ValueError, TypeError):
                    direct_deposit_amount = 0
                
                holding_period = 0
                try:
                    holding_period = int(row['holding_period']) if row['holding_period'] else 0
                except (ValueError, TypeError):
                    holding_period = 0
                
                # Create the bonus
                bonus_data = {
                    "title": row['title'],
                    "bank_id": bank_id,
                    "bonus_amount": bonus_amount,
                    "min_deposit": min_deposit,
                    "direct_deposit_required": row['direct_deposit_required'].lower() == 'true',
                    "direct_deposit_amount": direct_deposit_amount,
                    "holding_period": holding_period,
                    "additional_requirements": row['additional_requirements'],
                    "expiration_date": None,
                    "link": row['link'] if row['link'] else "",
                    "is_active": True
                }
                
                try:
                    bonus_response = requests.post(f"{api_base_url}/bonuses", json=bonus_data, timeout=30)
                    
                    if bonus_response.status_code in [200, 201]:
                        bonuses_created += 1
                        print(f"  ✓ Created bonus: {bonus_data['title']}")
                    else:
                        print(f"  ✗ Error creating bonus: {bonus_response.text}")
                        errors.append(f"Bonus creation failed for {bonus_data['title']}")
                        
                except requests.exceptions.RequestException as e:
                    print(f"  ✗ Network error creating bonus: {str(e)}")
                    errors.append(f"Network error for bonus {bonus_data['title']}")
                
                # Small delay to avoid overwhelming the API
                time.sleep(0.5)
                
            except Exception as e:
                print(f"  ✗ Unexpected error processing row: {str(e)}")
                errors.append(f"Unexpected error for {row.get('title', 'Unknown')}: {str(e)}")
                continue
    
    print(f"\n" + "="*50)
    print(f"UPLOAD SUMMARY")
    print(f"="*50)
    print(f"Banks created: {banks_created}")
    print(f"Bonuses created: {bonuses_created}")
    print(f"Errors: {len(errors)}")
    
    if errors:
        print(f"\nErrors encountered:")
        for error in errors[:10]:  # Show first 10 errors
            print(f"  - {error}")
        if len(errors) > 10:
            print(f"  ... and {len(errors) - 10} more errors")
    
    return bonuses_created > 0

if __name__ == "__main__":
    csv_file = "/home/ubuntu/bank_bonuses.csv"
    api_url = "https://2g8h3ilclk0x.manus.space/api"
    
    print("Starting bank bonus upload via API...")
    success = upload_bonuses_via_api(csv_file, api_url)
    if success:
        print("\nBank bonus upload completed successfully!")
    else:
        print("\nBank bonus upload failed!")

