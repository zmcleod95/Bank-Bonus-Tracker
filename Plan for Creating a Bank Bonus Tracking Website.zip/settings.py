from flask import Blueprint, jsonify, request
from src.models.models import PlayerSettings, db

settings_bp = Blueprint('settings', __name__)

@settings_bp.route('/player-settings', methods=['GET'])
def get_all_player_settings():
    settings = PlayerSettings.query.all()
    return jsonify([s.to_dict() for s in settings])

@settings_bp.route('/player-settings/<int:player_id>', methods=['GET'])
def get_player_settings(player_id):
    # Validate player_id
    if player_id not in [1, 2]:
        return jsonify({'error': 'Invalid player ID. Must be 1 or 2'}), 400
    
    settings = PlayerSettings.query.filter_by(player_id=player_id).first()
    
    if not settings:
        # Return default settings if none exist
        return jsonify({
            'player_id': player_id,
            'name': f'Player {player_id}'
        })
    
    return jsonify(settings.to_dict())

@settings_bp.route('/player-settings/<int:player_id>', methods=['PUT'])
def update_player_settings(player_id):
    # Validate player_id
    if player_id not in [1, 2]:
        return jsonify({'error': 'Invalid player ID. Must be 1 or 2'}), 400
    
    data = request.json
    
    # Validate required fields
    if 'name' not in data:
        return jsonify({'error': 'Name is required'}), 400
    
    settings = PlayerSettings.query.filter_by(player_id=player_id).first()
    
    if not settings:
        # Create new settings if none exist
        settings = PlayerSettings(
            player_id=player_id,
            name=data['name']
        )
        db.session.add(settings)
    else:
        # Update existing settings
        settings.name = data['name']
    
    db.session.commit()
    
    return jsonify(settings.to_dict())

@settings_bp.route('/player-settings', methods=['POST'])
def create_player_settings():
    data = request.json
    
    # Validate required fields
    required_fields = ['player_id', 'name']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'{field} is required'}), 400
    
    # Validate player_id
    if data['player_id'] not in [1, 2]:
        return jsonify({'error': 'Invalid player ID. Must be 1 or 2'}), 400
    
    # Check if settings already exist for this player
    existing = PlayerSettings.query.filter_by(player_id=data['player_id']).first()
    if existing:
        return jsonify({'error': f'Settings already exist for Player {data["player_id"]}'}), 400
    
    settings = PlayerSettings(
        player_id=data['player_id'],
        name=data['name']
    )
    
    db.session.add(settings)
    db.session.commit()
    
    return jsonify(settings.to_dict()), 201

