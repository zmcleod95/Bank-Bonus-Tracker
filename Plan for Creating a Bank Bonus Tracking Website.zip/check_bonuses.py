import requests
import json

def check_uploaded_bonuses():
    """Check how many bonuses were successfully uploaded"""
    
    api_url = "https://2g8h3ilclk0x.manus.space/api"
    
    try:
        print("Checking API health...")
        health_response = requests.get(f"{api_url}/health", timeout=10)
        print(f"Health check: {health_response.status_code} - {health_response.text}")
        
        print("\nChecking uploaded bonuses...")
        bonuses_response = requests.get(f"{api_url}/bonuses", timeout=10)
        print(f"Bonuses endpoint: {bonuses_response.status_code}")
        
        if bonuses_response.status_code == 200:
            bonuses = bonuses_response.json()
            print(f"Number of bonuses found: {len(bonuses)}")
            
            if bonuses:
                print("\nFirst few bonuses:")
                for i, bonus in enumerate(bonuses[:5]):
                    print(f"{i+1}. {bonus.get('title', 'Unknown')} - ${bonus.get('bonus_amount', 0)}")
                
                # Group by bank
                banks = {}
                for bonus in bonuses:
                    bank_id = bonus.get('bank_id')
                    if bank_id not in banks:
                        banks[bank_id] = []
                    banks[bank_id].append(bonus)
                
                print(f"\nBonuses distributed across {len(banks)} banks")
            else:
                print("No bonuses found in the database")
        else:
            print(f"Error getting bonuses: {bonuses_response.text}")
            
        print("\nChecking banks...")
        banks_response = requests.get(f"{api_url}/banks", timeout=10)
        print(f"Banks endpoint: {banks_response.status_code}")
        
        if banks_response.status_code == 200:
            banks = banks_response.json()
            print(f"Number of banks found: {len(banks)}")
            
            if banks:
                print("\nBanks:")
                for bank in banks:
                    print(f"- {bank.get('name', 'Unknown')}")
        else:
            print(f"Error getting banks: {banks_response.text}")
            
    except Exception as e:
        print(f"Error checking API: {str(e)}")

if __name__ == "__main__":
    check_uploaded_bonuses()

