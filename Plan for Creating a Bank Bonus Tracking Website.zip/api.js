import axios from 'axios';

// Define the API base URL
const API_URL = 'https://2g8h3ilclk0x.manus.space/api';

// Create axios instance
const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// API functions for banks
export const getBanks = async () => {
  const response = await api.get('/banks');
  return response.data;
};

export const getBank = async (id) => {
  const response = await api.get(`/banks/${id}`);
  return response.data;
};

export const createBank = async (bankData) => {
  const response = await api.post('/banks', bankData);
  return response.data;
};

export const updateBank = async (id, bankData) => {
  const response = await api.put(`/banks/${id}`, bankData);
  return response.data;
};

export const deleteBank = async (id) => {
  await api.delete(`/banks/${id}`);
  return true;
};

// API functions for bonuses
export const getBonuses = async () => {
  const response = await api.get('/bonuses');
  return response.data;
};

export const getBonus = async (id) => {
  const response = await api.get(`/bonuses/${id}`);
  return response.data;
};

export const getBankBonuses = async (bankId) => {
  const response = await api.get(`/banks/${bankId}/bonuses`);
  return response.data;
};

export const createBonus = async (bonusData) => {
  const response = await api.post('/bonuses', bonusData);
  return response.data;
};

export const updateBonus = async (id, bonusData) => {
  const response = await api.put(`/bonuses/${id}`, bonusData);
  return response.data;
};

export const deleteBonus = async (id) => {
  await api.delete(`/bonuses/${id}`);
  return true;
};

// API functions for tracked bonuses
export const getTrackedBonuses = async () => {
  const response = await api.get('/tracked-bonuses');
  return response.data;
};

export const getTrackedBonus = async (id) => {
  const response = await api.get(`/tracked-bonuses/${id}`);
  return response.data;
};

export const getPlayerTrackedBonuses = async (playerId) => {
  const response = await api.get(`/players/${playerId}/tracked-bonuses`);
  return response.data;
};

export const createTrackedBonus = async (trackedBonusData) => {
  const response = await api.post('/tracked-bonuses', trackedBonusData);
  return response.data;
};

export const updateTrackedBonus = async (id, trackedBonusData) => {
  const response = await api.put(`/tracked-bonuses/${id}`, trackedBonusData);
  return response.data;
};

export const deleteTrackedBonus = async (id) => {
  await api.delete(`/tracked-bonuses/${id}`);
  return true;
};

// API functions for player settings
export const getPlayerSettings = async (playerId) => {
  const response = await api.get(`/player-settings/${playerId}`);
  return response.data;
};

export const updatePlayerSettings = async (playerId, settingsData) => {
  const response = await api.put(`/player-settings/${playerId}`, settingsData);
  return response.data;
};

// API function for dashboard data
export const getDashboardData = async () => {
  const response = await api.get('/dashboard');
  return response.data;
};

export default {
  getBanks,
  getBank,
  createBank,
  updateBank,
  deleteBank,
  getBonuses,
  getBonus,
  getBankBonuses,
  createBonus,
  updateBonus,
  deleteBonus,
  getTrackedBonuses,
  getTrackedBonus,
  getPlayerTrackedBonuses,
  createTrackedBonus,
  updateTrackedBonus,
  deleteTrackedBonus,
  getPlayerSettings,
  updatePlayerSettings,
  getDashboardData
};

