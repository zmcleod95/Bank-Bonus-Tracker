import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { PlayerProvider } from '@/context/PlayerContext';
import Layout from '@/components/layout/Layout';
import Dashboard from '@/pages/Dashboard';
import BonusCatalog from '@/pages/BonusCatalog';
import BonusDetail from '@/pages/BonusDetail';
import Tracking from '@/pages/Tracking';
import Comparison from '@/pages/Comparison';
import Settings from '@/pages/Settings';
import NotFound from '@/pages/NotFound';
import './App.css';

// Create a client
const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <PlayerProvider>
        <Router>
          <Routes>
            <Route path="/" element={<Layout />}>
              <Route index element={<Dashboard />} />
              <Route path="bonuses" element={<BonusCatalog />} />
              <Route path="bonuses/:id" element={<BonusDetail />} />
              <Route path="tracking" element={<Tracking />} />
              <Route path="comparison" element={<Comparison />} />
              <Route path="settings" element={<Settings />} />
              <Route path="*" element={<NotFound />} />
            </Route>
          </Routes>
        </Router>
      </PlayerProvider>
    </QueryClientProvider>
  );
}

export default App;

