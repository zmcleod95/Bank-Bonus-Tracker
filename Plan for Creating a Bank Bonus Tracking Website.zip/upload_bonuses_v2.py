#!/usr/bin/env python3
import csv
import os
import sys

# Set the working directory to the API directory
os.chdir('/home/ubuntu/bank-bonus-tracker-api')

# Add the project root to the path
sys.path.insert(0, '/home/ubuntu/bank-bonus-tracker-api')

# Import the Flask app and models
from src.main import app
from src.models.models import db, Bank, Bonus

def upload_bonuses_from_csv(csv_file_path):
    """Upload bank bonuses from CSV file to the database"""
    
    with app.app_context():
        # Read the CSV file
        with open(csv_file_path, 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            
            banks_created = 0
            bonuses_created = 0
            
            for row in reader:
                try:
                    # Check if bank exists, if not create it
                    bank = Bank.query.filter_by(name=row['bank_name']).first()
                    if not bank:
                        bank = Bank(
                            name=row['bank_name'],
                            logo='',  # We'll add logos later if needed
                            website=row['link'] if row['link'] else ''
                        )
                        db.session.add(bank)
                        db.session.flush()  # Get the ID
                        banks_created += 1
                        print(f"Created bank: {bank.name}")
                    
                    # Check if bonus already exists
                    existing_bonus = Bonus.query.filter_by(
                        title=row['title'],
                        bank_id=bank.id
                    ).first()
                    
                    if existing_bonus:
                        print(f"Bonus already exists: {row['title']}")
                        continue
                    
                    # Parse numeric values safely
                    bonus_amount = 0
                    try:
                        bonus_amount = float(row['bonus_amount']) if row['bonus_amount'] else 0
                    except (ValueError, TypeError):
                        bonus_amount = 0
                    
                    min_deposit = 0
                    try:
                        min_deposit = float(row['min_deposit']) if row['min_deposit'] else 0
                    except (ValueError, TypeError):
                        min_deposit = 0
                    
                    direct_deposit_amount = 0
                    try:
                        direct_deposit_amount = float(row['direct_deposit_amount']) if row['direct_deposit_amount'] else 0
                    except (ValueError, TypeError):
                        direct_deposit_amount = 0
                    
                    holding_period = 0
                    try:
                        holding_period = int(row['holding_period']) if row['holding_period'] else 0
                    except (ValueError, TypeError):
                        holding_period = 0
                    
                    # Create the bonus
                    bonus = Bonus(
                        title=row['title'],
                        bank_id=bank.id,
                        bonus_amount=bonus_amount,
                        min_deposit=min_deposit,
                        direct_deposit_required=row['direct_deposit_required'].lower() == 'true',
                        direct_deposit_amount=direct_deposit_amount,
                        holding_period=holding_period,
                        additional_requirements=row['additional_requirements'],
                        expiration_date=None,  # We'll parse dates later if needed
                        link=row['link'] if row['link'] else '',
                        is_active=True
                    )
                    
                    db.session.add(bonus)
                    bonuses_created += 1
                    print(f"Created bonus: {bonus.title}")
                    
                except Exception as e:
                    print(f"Error processing row {row.get('title', 'Unknown')}: {str(e)}")
                    continue
            
            # Commit all changes
            try:
                db.session.commit()
                print(f"\nSuccessfully uploaded:")
                print(f"- {banks_created} new banks")
                print(f"- {bonuses_created} new bonuses")
                return True
            except Exception as e:
                db.session.rollback()
                print(f"Error committing to database: {str(e)}")
                return False

if __name__ == "__main__":
    csv_file = "/home/ubuntu/bank_bonuses.csv"
    
    if os.path.exists(csv_file):
        print("Starting bank bonus upload...")
        success = upload_bonuses_from_csv(csv_file)
        if success:
            print("Bank bonus upload completed successfully!")
        else:
            print("Bank bonus upload failed!")
    else:
        print(f"CSV file not found: {csv_file}")

