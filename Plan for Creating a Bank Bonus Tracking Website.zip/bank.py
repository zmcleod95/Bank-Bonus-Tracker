from flask import Blueprint, jsonify, request
from src.models.models import Bank, db

bank_bp = Blueprint('bank', __name__)

@bank_bp.route('/banks', methods=['GET'])
def get_banks():
    banks = Bank.query.all()
    return jsonify([bank.to_dict() for bank in banks])

@bank_bp.route('/banks/<int:bank_id>', methods=['GET'])
def get_bank(bank_id):
    bank = Bank.query.get_or_404(bank_id)
    return jsonify(bank.to_dict())

@bank_bp.route('/banks', methods=['POST'])
def create_bank():
    data = request.json
    
    # Validate required fields
    if not data.get('name'):
        return jsonify({'error': 'Name is required'}), 400
    
    bank = Bank(
        name=data['name'],
        logo=data.get('logo'),
        website=data.get('website'),
        description=data.get('description')
    )
    
    db.session.add(bank)
    db.session.commit()
    
    return jsonify(bank.to_dict()), 201

@bank_bp.route('/banks/<int:bank_id>', methods=['PUT'])
def update_bank(bank_id):
    bank = Bank.query.get_or_404(bank_id)
    data = request.json
    
    # Update fields if provided
    if 'name' in data:
        bank.name = data['name']
    if 'logo' in data:
        bank.logo = data['logo']
    if 'website' in data:
        bank.website = data['website']
    if 'description' in data:
        bank.description = data['description']
    
    db.session.commit()
    
    return jsonify(bank.to_dict())

@bank_bp.route('/banks/<int:bank_id>', methods=['DELETE'])
def delete_bank(bank_id):
    bank = Bank.query.get_or_404(bank_id)
    
    # Check if bank has associated bonuses
    if bank.bonuses:
        return jsonify({'error': 'Cannot delete bank with associated bonuses'}), 400
    
    db.session.delete(bank)
    db.session.commit()
    
    return '', 204

