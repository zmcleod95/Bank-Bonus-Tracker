from flask import Blueprint, jsonify, request
from src.models.models import TrackedBonus, Bonus, db
from datetime import datetime

tracked_bonus_bp = Blueprint('tracked_bonus', __name__)

@tracked_bonus_bp.route('/tracked-bonuses', methods=['GET'])
def get_tracked_bonuses():
    tracked_bonuses = TrackedBonus.query.all()
    return jsonify([tb.to_dict() for tb in tracked_bonuses])

@tracked_bonus_bp.route('/tracked-bonuses/<int:tracked_bonus_id>', methods=['GET'])
def get_tracked_bonus(tracked_bonus_id):
    tracked_bonus = TrackedBonus.query.get_or_404(tracked_bonus_id)
    return jsonify(tracked_bonus.to_dict())

@tracked_bonus_bp.route('/players/<int:player_id>/tracked-bonuses', methods=['GET'])
def get_player_tracked_bonuses(player_id):
    # Validate player_id
    if player_id not in [1, 2]:
        return jsonify({'error': 'Invalid player ID. Must be 1 or 2'}), 400
    
    tracked_bonuses = TrackedBonus.query.filter_by(player_id=player_id).all()
    
    # Get detailed information including bonus and bank details
    result = []
    for tb in tracked_bonuses:
        tb_dict = tb.to_dict()
        bonus = Bonus.query.get(tb.bonus_id)
        if bonus:
            tb_dict['bonus'] = bonus.to_dict()
            if bonus.bank:
                tb_dict['bank'] = bonus.bank.to_dict()
        result.append(tb_dict)
    
    return jsonify(result)

@tracked_bonus_bp.route('/tracked-bonuses', methods=['POST'])
def create_tracked_bonus():
    data = request.json
    
    # Validate required fields
    required_fields = ['player_id', 'bonus_id', 'status']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'{field} is required'}), 400
    
    # Validate player_id
    if data['player_id'] not in [1, 2]:
        return jsonify({'error': 'Invalid player ID. Must be 1 or 2'}), 400
    
    # Verify bonus exists
    bonus = Bonus.query.get(data['bonus_id'])
    if not bonus:
        return jsonify({'error': 'Bonus not found'}), 404
    
    # Parse dates if provided
    date_fields = ['application_date', 'account_open_date', 'direct_deposit_date', 
                  'bonus_received_date', 'completion_date']
    parsed_dates = {}
    
    for field in date_fields:
        if field in data and data[field]:
            try:
                parsed_dates[field] = datetime.fromisoformat(data[field].replace('Z', '+00:00')).date()
            except ValueError:
                return jsonify({'error': f'Invalid {field} format'}), 400
    
    tracked_bonus = TrackedBonus(
        player_id=data['player_id'],
        bonus_id=data['bonus_id'],
        status=data['status'],
        application_date=parsed_dates.get('application_date'),
        account_open_date=parsed_dates.get('account_open_date'),
        initial_deposit=data.get('initial_deposit', 0.0),
        direct_deposit_complete=data.get('direct_deposit_complete', False),
        direct_deposit_date=parsed_dates.get('direct_deposit_date'),
        bonus_received_date=parsed_dates.get('bonus_received_date'),
        completion_date=parsed_dates.get('completion_date'),
        actual_earnings=data.get('actual_earnings', 0.0),
        notes=data.get('notes'),
        is_active=data.get('is_active', True)
    )
    
    db.session.add(tracked_bonus)
    db.session.commit()
    
    return jsonify(tracked_bonus.to_dict()), 201

@tracked_bonus_bp.route('/tracked-bonuses/<int:tracked_bonus_id>', methods=['PUT'])
def update_tracked_bonus(tracked_bonus_id):
    tracked_bonus = TrackedBonus.query.get_or_404(tracked_bonus_id)
    data = request.json
    
    # Update fields if provided
    if 'player_id' in data:
        # Validate player_id
        if data['player_id'] not in [1, 2]:
            return jsonify({'error': 'Invalid player ID. Must be 1 or 2'}), 400
        tracked_bonus.player_id = data['player_id']
    
    if 'bonus_id' in data:
        # Verify bonus exists
        bonus = Bonus.query.get(data['bonus_id'])
        if not bonus:
            return jsonify({'error': 'Bonus not found'}), 404
        tracked_bonus.bonus_id = data['bonus_id']
    
    if 'status' in data:
        tracked_bonus.status = data['status']
    
    # Parse dates if provided
    date_fields = {
        'application_date': 'application_date',
        'account_open_date': 'account_open_date',
        'direct_deposit_date': 'direct_deposit_date',
        'bonus_received_date': 'bonus_received_date',
        'completion_date': 'completion_date'
    }
    
    for api_field, model_field in date_fields.items():
        if api_field in data:
            if data[api_field]:
                try:
                    setattr(tracked_bonus, model_field, 
                            datetime.fromisoformat(data[api_field].replace('Z', '+00:00')).date())
                except ValueError:
                    return jsonify({'error': f'Invalid {api_field} format'}), 400
            else:
                setattr(tracked_bonus, model_field, None)
    
    if 'initial_deposit' in data:
        tracked_bonus.initial_deposit = data['initial_deposit']
    if 'direct_deposit_complete' in data:
        tracked_bonus.direct_deposit_complete = data['direct_deposit_complete']
    if 'actual_earnings' in data:
        tracked_bonus.actual_earnings = data['actual_earnings']
    if 'notes' in data:
        tracked_bonus.notes = data['notes']
    if 'is_active' in data:
        tracked_bonus.is_active = data['is_active']
    
    db.session.commit()
    
    return jsonify(tracked_bonus.to_dict())

@tracked_bonus_bp.route('/tracked-bonuses/<int:tracked_bonus_id>', methods=['DELETE'])
def delete_tracked_bonus(tracked_bonus_id):
    tracked_bonus = TrackedBonus.query.get_or_404(tracked_bonus_id)
    
    db.session.delete(tracked_bonus)
    db.session.commit()
    
    return '', 204

