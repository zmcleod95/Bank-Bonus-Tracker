from flask import Blueprint, jsonify, request
from src.models.models import Bonus, Bank, db
from datetime import datetime

bonus_bp = Blueprint('bonus', __name__)

@bonus_bp.route('/bonuses', methods=['GET'])
def get_bonuses():
    bonuses = Bonus.query.all()
    return jsonify([bonus.to_dict() for bonus in bonuses])

@bonus_bp.route('/bonuses/<int:bonus_id>', methods=['GET'])
def get_bonus(bonus_id):
    bonus = Bonus.query.get_or_404(bonus_id)
    return jsonify(bonus.to_dict())

@bonus_bp.route('/banks/<int:bank_id>/bonuses', methods=['GET'])
def get_bank_bonuses(bank_id):
    # Verify bank exists
    Bank.query.get_or_404(bank_id)
    
    bonuses = Bonus.query.filter_by(bank_id=bank_id).all()
    return jsonify([bonus.to_dict() for bonus in bonuses])

@bonus_bp.route('/bonuses', methods=['POST'])
def create_bonus():
    data = request.json
    
    # Validate required fields
    required_fields = ['bank_id', 'title', 'bonus_amount', 'holding_period']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'{field} is required'}), 400
    
    # Verify bank exists
    bank = Bank.query.get(data['bank_id'])
    if not bank:
        return jsonify({'error': 'Bank not found'}), 404
    
    # Parse expiration date if provided
    expiration_date = None
    if data.get('expiration_date'):
        try:
            expiration_date = datetime.fromisoformat(data['expiration_date'].replace('Z', '+00:00'))
        except ValueError:
            return jsonify({'error': 'Invalid expiration date format'}), 400
    
    bonus = Bonus(
        bank_id=data['bank_id'],
        title=data['title'],
        bonus_amount=data['bonus_amount'],
        interest_rate=data.get('interest_rate', 0.0),
        min_deposit=data.get('min_deposit', 0.0),
        holding_period=data['holding_period'],
        direct_deposit_required=data.get('direct_deposit_required', False),
        direct_deposit_amount=data.get('direct_deposit_amount', 0.0),
        direct_deposit_frequency=data.get('direct_deposit_frequency', ''),
        additional_requirements=data.get('additional_requirements'),
        expiration_date=expiration_date,
        terms_conditions=data.get('terms_conditions'),
        link=data.get('link'),
        is_active=data.get('is_active', True)
    )
    
    db.session.add(bonus)
    db.session.commit()
    
    return jsonify(bonus.to_dict()), 201

@bonus_bp.route('/bonuses/<int:bonus_id>', methods=['PUT'])
def update_bonus(bonus_id):
    bonus = Bonus.query.get_or_404(bonus_id)
    data = request.json
    
    # Update fields if provided
    if 'bank_id' in data:
        # Verify bank exists
        bank = Bank.query.get(data['bank_id'])
        if not bank:
            return jsonify({'error': 'Bank not found'}), 404
        bonus.bank_id = data['bank_id']
    
    if 'title' in data:
        bonus.title = data['title']
    if 'bonus_amount' in data:
        bonus.bonus_amount = data['bonus_amount']
    if 'interest_rate' in data:
        bonus.interest_rate = data['interest_rate']
    if 'min_deposit' in data:
        bonus.min_deposit = data['min_deposit']
    if 'holding_period' in data:
        bonus.holding_period = data['holding_period']
    if 'direct_deposit_required' in data:
        bonus.direct_deposit_required = data['direct_deposit_required']
    if 'direct_deposit_amount' in data:
        bonus.direct_deposit_amount = data['direct_deposit_amount']
    if 'direct_deposit_frequency' in data:
        bonus.direct_deposit_frequency = data['direct_deposit_frequency']
    if 'additional_requirements' in data:
        bonus.additional_requirements = data['additional_requirements']
    
    # Parse expiration date if provided
    if 'expiration_date' in data:
        if data['expiration_date']:
            try:
                bonus.expiration_date = datetime.fromisoformat(data['expiration_date'].replace('Z', '+00:00'))
            except ValueError:
                return jsonify({'error': 'Invalid expiration date format'}), 400
        else:
            bonus.expiration_date = None
    
    if 'terms_conditions' in data:
        bonus.terms_conditions = data['terms_conditions']
    if 'link' in data:
        bonus.link = data['link']
    if 'is_active' in data:
        bonus.is_active = data['is_active']
    
    db.session.commit()
    
    return jsonify(bonus.to_dict())

@bonus_bp.route('/bonuses/<int:bonus_id>', methods=['DELETE'])
def delete_bonus(bonus_id):
    bonus = Bonus.query.get_or_404(bonus_id)
    
    # Check if bonus has associated tracked bonuses
    if bonus.tracked_bonuses:
        return jsonify({'error': 'Cannot delete bonus with associated tracked bonuses'}), 400
    
    db.session.delete(bonus)
    db.session.commit()
    
    return '', 204

