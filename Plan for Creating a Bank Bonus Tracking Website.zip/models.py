from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Bank(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    logo = db.Column(db.String(255))
    website = db.Column(db.String(255))
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    bonuses = db.relationship('Bonus', backref='bank', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'logo': self.logo,
            'website': self.website,
            'description': self.description,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }


class Bonus(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    bank_id = db.Column(db.Integer, db.ForeignKey('bank.id'), nullable=False)
    title = db.Column(db.String(255), nullable=False)
    bonus_amount = db.Column(db.Float, nullable=False)
    interest_rate = db.Column(db.Float, default=0.0)
    min_deposit = db.Column(db.Float, default=0.0)
    holding_period = db.Column(db.Integer, nullable=False)  # in days
    direct_deposit_required = db.Column(db.Boolean, default=False)
    direct_deposit_amount = db.Column(db.Float, default=0.0)
    direct_deposit_frequency = db.Column(db.String(50))  # e.g., "monthly", "one-time"
    additional_requirements = db.Column(db.Text)
    expiration_date = db.Column(db.Date)
    terms_conditions = db.Column(db.Text)
    link = db.Column(db.String(255))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    tracked_bonuses = db.relationship('TrackedBonus', backref='bonus', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'bank_id': self.bank_id,
            'title': self.title,
            'bonus_amount': self.bonus_amount,
            'interest_rate': self.interest_rate,
            'min_deposit': self.min_deposit,
            'holding_period': self.holding_period,
            'direct_deposit_required': self.direct_deposit_required,
            'direct_deposit_amount': self.direct_deposit_amount,
            'direct_deposit_frequency': self.direct_deposit_frequency,
            'additional_requirements': self.additional_requirements,
            'expiration_date': self.expiration_date.isoformat() if self.expiration_date else None,
            'terms_conditions': self.terms_conditions,
            'link': self.link,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }


class TrackedBonus(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    player_id = db.Column(db.Integer, nullable=False)  # 1 or 2 for Player 1 or Player 2
    bonus_id = db.Column(db.Integer, db.ForeignKey('bonus.id'), nullable=False)
    status = db.Column(db.String(50), nullable=False, default='planned')  # planned, applied, account_opened, requirements_met, bonus_received, completed, failed
    application_date = db.Column(db.Date)
    account_open_date = db.Column(db.Date)
    initial_deposit = db.Column(db.Float, default=0.0)
    direct_deposit_complete = db.Column(db.Boolean, default=False)
    direct_deposit_date = db.Column(db.Date)
    bonus_received_date = db.Column(db.Date)
    completion_date = db.Column(db.Date)
    actual_earnings = db.Column(db.Float, default=0.0)
    notes = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'player_id': self.player_id,
            'bonus_id': self.bonus_id,
            'status': self.status,
            'application_date': self.application_date.isoformat() if self.application_date else None,
            'account_open_date': self.account_open_date.isoformat() if self.account_open_date else None,
            'initial_deposit': self.initial_deposit,
            'direct_deposit_complete': self.direct_deposit_complete,
            'direct_deposit_date': self.direct_deposit_date.isoformat() if self.direct_deposit_date else None,
            'bonus_received_date': self.bonus_received_date.isoformat() if self.bonus_received_date else None,
            'completion_date': self.completion_date.isoformat() if self.completion_date else None,
            'actual_earnings': self.actual_earnings,
            'notes': self.notes,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }


class PlayerSettings(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    player_id = db.Column(db.Integer, nullable=False, unique=True)  # 1 or 2 for Player 1 or Player 2
    name = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'player_id': self.player_id,
            'name': self.name,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

